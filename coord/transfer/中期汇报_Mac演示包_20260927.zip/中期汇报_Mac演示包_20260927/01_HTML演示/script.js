/* 中期检查汇报 deck · 翻页、交叉淡出与讲稿备注
   2026-09-27 动效版：show() 把旧页挂 .leaving（绝对定位叠在新页下淡出 320ms），
   新页内容由 CSS（styles.css 动效段）按 nth-child 节奏逐级浮现。
   打印／导出走 @media print（动效自动关闭）；测量与截图工具给 <html> 加 .no-anim 冻结终态。
   第二批：时序图八步播放器（累积点亮、点击图面重播）、生命线流动、数据包与智能化脉冲见 styles.css。 */
(function () {
  var slides = Array.prototype.slice.call(document.querySelectorAll('.slide'));
  var notes = document.getElementById('notes');
  var notesBody = document.getElementById('notes-body');
  var idx = 0;
  var LEAVE_MS = 380;

  function clamp(n) { return Math.max(0, Math.min(slides.length - 1, n)); }

  function show(n) {
    var target = clamp(n);
    var prev = slides[idx];
    slides.forEach(function (s, i) {
      var on = (i === target);
      s.classList.toggle('active', on);
      if (on && s.classList.contains('leaving')) {
        if (s._lt) { clearTimeout(s._lt); s._lt = null; }
        s.classList.remove('leaving');
      }
    });
    if (prev && prev !== slides[target]) {
      prev.classList.add('leaving');
      if (prev._lt) clearTimeout(prev._lt);
      prev._lt = setTimeout(function () {
        prev.classList.remove('leaving');
        prev._lt = null;
      }, LEAVE_MS);
    }
    idx = target;
    var cur = slides[idx];
    if (cur.querySelector('.seq-step')) playSeq(cur); else stopSeq();
    if (notesBody) {
      var note = slides[idx].querySelector('.speaker-note');
      notesBody.innerHTML = note ? note.innerHTML : '<div class="sec">（本页无讲稿备注）</div>';
    }
    if (location.hash !== '#slide-' + (idx + 1)) {
      history.replaceState(null, '', '#slide-' + (idx + 1));
    }
    window.scrollTo(0, 0);
  }

  function next() { show(idx + 1); }
  function prev() { show(idx - 1); }

  /* 自由态时序图：八步按节奏点亮（累积制），点击图面重播；
     打印／no-anim 态由 CSS 冻结为完整终态，不依赖此处。 */
  var seqTimer = null;
  function stopSeq() { if (seqTimer) { clearInterval(seqTimer); seqTimer = null; } }
  function playSeq(slideEl) {
    var svg = slideEl.querySelector('.d-seq');
    var steps = Array.prototype.slice.call(slideEl.querySelectorAll('.seq-step'))
      .sort(function (a, b) { return (+a.getAttribute('data-step')) - (+b.getAttribute('data-step')); });
    if (!svg || !steps.length) return;
    stopSeq();
    svg.classList.remove('done');
    steps.forEach(function (el) { el.classList.remove('on', 'past'); });
    var i = 0;
    var advance = function () {
      if (i >= steps.length) { svg.classList.add('done'); stopSeq(); return; }
      steps[i].classList.add('on');
      i += 1;
    };
    // 先让创作者（0.1s）与智能体（0.5s）出场，再开始第一步
    setTimeout(advance, 950);
    seqTimer = setInterval(advance, 620);
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown' || e.key === 'Enter') {
      e.preventDefault(); next();
    } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
      e.preventDefault(); prev();
    } else if (e.key === 'Home') {
      e.preventDefault(); show(0);
    } else if (e.key === 'End') {
      e.preventDefault(); show(slides.length - 1);
    } else if (e.key === 'n' || e.key === 'N') {
      if (notes) notes.classList.toggle('show');
    }
  });

  // 支持 #slide-N 锚点直达；翻页时同步 hash
  function fromHash() {
    var m = /^#slide-(\d+)$/.exec(location.hash || '');
    if (m) { show(parseInt(m[1], 10) - 1); return true; }
    return false;
  }
  window.addEventListener('hashchange', fromHash);

  /* p8 架构下钻：点击节点展开内部设计，再点收起 */
  document.querySelectorAll('.anode').forEach(function (node) {
    node.addEventListener('click', function (e) {
      e.stopPropagation();
      var key = this.getAttribute('data-node');
      var panel = document.querySelector('.arch-detail[data-for="' + key + '"]');
      var wasShown = panel.classList.contains('show');
      document.querySelectorAll('.arch-detail.show').forEach(function (p) { p.classList.remove('show'); });
      document.querySelectorAll('.anode.sel').forEach(function (n) { n.classList.remove('sel'); });
      if (!wasShown) { panel.classList.add('show'); this.classList.add('sel'); }
    });
  });

  /* 屏幕翻页按钮＋触屏滑动（手机／触屏／焦点不在页面时可用） */
  var navPrev = document.createElement('button');
  navPrev.className = 'navbtn prev';
  navPrev.title = '上一页';
  navPrev.innerHTML = '&#8249;';
  var navNext = document.createElement('button');
  navNext.className = 'navbtn next';
  navNext.title = '下一页';
  navNext.innerHTML = '&#8250;';
  document.body.appendChild(navPrev);
  document.body.appendChild(navNext);
  navPrev.addEventListener('click', function (e) { e.stopPropagation(); prev(); });
  navNext.addEventListener('click', function (e) { e.stopPropagation(); next(); });
  var touchX = null;
  document.addEventListener('touchstart', function (e) {
    if (e.touches.length === 1) touchX = e.touches[0].clientX;
  }, { passive: true });
  document.addEventListener('touchend', function (e) {
    if (touchX === null) return;
    var dx = e.changedTouches[0].clientX - touchX;
    touchX = null;
    if (Math.abs(dx) > 40) { if (dx < 0) next(); else prev(); }
  }, { passive: true });

  var seqSvg = document.querySelector('.d-seq');
  if (seqSvg) seqSvg.addEventListener('click', function () { show(idx); });

  if (!fromHash()) show(0);
  document.title = document.title + '（共 ' + slides.length + ' 页）';
})();
